/**
 * Internal dependencies.
 */
import './email-communication';
